module promotiontest {
	exports ch09;
	exports ch16;
	exports ch17;
	exports com.keduit;
	exports com.keduitts;
	exports ch14;
	exports ch15;
	exports ch12;
	exports com.test;
	exports ch10;
	exports ch11;
	exports com.keduits;
}