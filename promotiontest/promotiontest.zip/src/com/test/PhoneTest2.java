package com.test;

public class PhoneTest2 {

	public static void main(String[] args) {
		
		PhoneTest phone = new PhoneTest();
		
		
		System.out.println(phone.model);
		

	}

}
