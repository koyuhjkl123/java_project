package com.test;

public class Exam01_Book{
	
//	책은 아래의 정보를 갖는다.
//	제목
	
//	책은 아래의 동작을 수행 할 수 있다.
//	책 제목을 문자열로 반환
	
	String title; // 책 제목
	
	public Exam01_Book(String title) {
		this.title = title;
	}
	public String getTitle() {
		return title;
	}
	
}
