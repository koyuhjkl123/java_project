package com.test;


public class PhoneTest {
	
	String model;
	int ss;
	int value;
	
	void Phone(String model, int value) {
		this.model = model;
		this.value = value;
		System.out.println("값");
		System.out.println(model);
		System.out.println(value);
	}

}


