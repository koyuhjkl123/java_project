package com.test;

import java.util.Objects;

public class Exam01_Drink {

//	음료는 아래의 정보를 갖는다.
//	이름, 가격

//	음료는 아래의 동작을 수행 할 수 있다.
//	음료 정보를 문자열로 반환

	String drink;
	int price;

	public Exam01_Drink(String drink, int price) {
		this.drink = drink;
		this.price = price;
	}

	public String getDrinks() {
		return drink + "- " + price + "원\n";
	}

	public String getDrink() {
		return drink;
	}

	public int getPrice() {
		return price;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}

		Exam01_Drink other = (Exam01_Drink) obj;
		return price == other.price && Objects.equals(drink, other.drink);
	}

	// hashCode() 메서드도 오버라이드하는 것이 좋습니다.
	@Override
	public int hashCode() {
		return Objects.hash(drink, price);
	}
}
