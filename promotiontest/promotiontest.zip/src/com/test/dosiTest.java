package com.test;

import java.util.HashSet;
import java.util.Set;

public class dosiTest {

	public static void main(String[] args) {

		Set<String> gyeong_count = new HashSet<String>();
		
		// 중복을 허용하지 않게 10개의 Set<String> 타입인 값이 있다.
		dosi dosi = new dosi(gyeong_count);
		
		dosi.stringBuilders();
		
//		colletors를 이용..
		
		
		
		

	}

}
