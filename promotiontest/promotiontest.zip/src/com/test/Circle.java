package com.test;

public class Circle {
	
	private double radius;
	
	public double getRadius() {
		return radius;
	}
	
	

}
