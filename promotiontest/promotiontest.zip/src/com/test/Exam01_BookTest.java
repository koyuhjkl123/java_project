package com.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

public class Exam01_BookTest {

//	북 카페를 이루고있는 구성요소를 클래스로 설계하세요.
//	설계를 토대로 소스코드를 작성하세요.
//	작성된 소스코드가 요구사항을 충족하도록 프로그램을 만들어 주세요.

//	구성 요소 : 북 카페, 책, 음료 < 
//	요구사항 : 이름, 주소, 여러권의 책, 다양한 음료

//	북 카페는 아래와 같이 동작을 실행한다.

//	새로운 음료를 추가하거나, 기존 음료를 삭제
//	카페의 정보를 요약하여 출력

	String name; // 책 이름
	String address; // 주소
	String[] names; // 여러권의 책
	String[] dirnks; // 다양한 음료

	String add_book; // 책을 추가할 book 정보를 저장
	String remove_book; // 책을 삭제할 book 정보를 저장

	String add_drink; // 음료를 추가할 음료 정보를 저장
	String remove_drink; // 음료를 삭제할 음료 정보를 저장
	int drink_price;

	StringBuilder book_data;
	StringBuilder drink_data;

//	구성요소 책, 이름
	List<Exam01_Book> books = new ArrayList<Exam01_Book>();
	List<Exam01_Drink> drinks = new ArrayList<Exam01_Drink>();

	public Exam01_BookTest(String name, String address) {
		this.name = name;
		this.address = address;

//		보유 서적 : 예제로 배우는 Java, HTML 웹페이지 만들기, 슬램덩크, 자료구조
		books.add(new Exam01_Book("예제로 배우는 Java"));
		books.add(new Exam01_Book("HTML 웹페이지 만들기"));
		books.add(new Exam01_Book("슬램덩크"));
		books.add(new Exam01_Book("자료구조"));

//		보유 음료 아메리카노, 라떼, 레몬에이드, 캔맥주
		drinks.add(new Exam01_Drink("아메리카노", 2000));
		drinks.add(new Exam01_Drink("라떼", 2500));
		drinks.add(new Exam01_Drink("레몬에이드", 3000));
		drinks.add(new Exam01_Drink("캔맥주", 3500));

	}


	@Override
	public String toString() { // 책을 출력
		StringBuilder ab = new StringBuilder();

//		책, 음료 각 추가 및 삭제에 대한 정보가 없으면 기존 정보 출력
		if ((add_book == null && remove_book == null) && (add_drink == null && remove_drink == null)) {
			ab.append("== 카페 정보 ==\n");
		} else if ((add_book != null && remove_book == null)) {
			ab.append(book_data); // 책추가
			ab.append("== 카페 정보 ==\n");
			add_book = null;

		} else if (add_book == null && remove_book != null) {
			ab.append(book_data); // 책 삭제
			ab.append("== 카페 정보 ==\n");
			remove_book = null;
		} else if ((add_drink != null && remove_drink == null)) {
			ab.append(drink_data); // 음료 추가
			ab.append("== 카페 정보 ==\n");
			add_drink = null;
		} else if ((add_drink == null && remove_drink != null)) {
			ab.append(drink_data); // 음료 삭제
			ab.append("== 카페 정보 ==\n");

		}

		ab.append(String.format("이름 : %s\n", name)); // IT 카페
		ab.append(String.format("주소 : %s\n", address)); // 신림역 3번 출구
		ab.append("보유 서적 : \n");
		books.forEach(book -> ab.append(book.getTitle() + "\n"));
		ab.append("판매 음료: \n");
		drinks.forEach(drink -> ab.append(drink.getDrinks()));
		return ab.toString();
	}

//	새로운 책을 등록 / 기존의 있던 Book을 검사
	public StringBuilder BookAdd(String book1) {
		StringBuilder ab = new StringBuilder();
		add_book = book1; // 추가할 책을 저장

		boolean isbook = false;

		for (int i = 0; i < books.size(); i++) {
			if ((books.get(i).getTitle().equals(book1))) {
				isbook = true;
				break;
			}
		}
		if (!isbook) {
			books.add(new Exam01_Book(book1));
			book_data = ab.append("== 책 추가 ==\n\n");
			add_book = null;
			return ab;
		}
		return ab;
	}

//	음료를 추가
	public StringBuilder DrinkAdd(String drink, int price) {
		this.add_drink = drink;
		drink_price = price;
		StringBuilder ab = new StringBuilder();

		boolean isdrink = false; // 중복 여부 체크

		for (int i = 0; i < drinks.size(); i++) {
			if ((drinks.get(i).getDrink().equals(drink))) {
				isdrink = true; // 기존에 등록된 음료라면 true로 변경
				break; // 중복된 음료이면 반복문에서 빠져 나가기
			}
		}
		if (!isdrink) {
			drinks.add(new Exam01_Drink(drink, price)); // 기존에 등록된 음료가 없다면 등록
			drink_data = ab.append("==" + drink + "추가 ==\n\n"); // 음료가 추가 됬으면 문구 등록
		}
		return ab;
	}

	
	// 등록된 책을 삭제
	public void BookrRemove(String book1) {
		remove_book = book1;
		StringBuilder ab = new StringBuilder();

		for (int i = 0; i < books.size(); i++) {
			if (books.get(i).getTitle().equals(book1)) {
				books.remove(i);
				book_data = ab.append("== 책 삭제 ==\n\n");
				break;
			}
		}
	}

//	음료를 삭제
	public StringBuilder DrinkRemove(String drink, int price) {
		remove_drink = drink;
		StringBuilder ab = new StringBuilder();

		for(int i =0; i < drinks.size(); i++) {
			if(drinks.get(i).getDrink().equals(drink) && drinks.get(i).getPrice() == price) {
				drinks.remove(i);
				drink_data = ab.append("== " + drink + " 삭제 ==\n\n");
			}
		}
		return ab;
	}
	public static void main(String[] args) {

		Exam01_BookTest bok = new Exam01_BookTest("IT 카페", "신림역 3번출구");

		System.out.println(bok);
		bok.BookAdd("자바프로그래밍");
		bok.BookAdd("자바프로그래밍");
		System.out.println(bok);
		bok.BookrRemove("자바프로그래밍");
		System.out.println(bok);

		bok.DrinkAdd("콜라", 2500);
		System.out.println(bok);
		bok.DrinkRemove("캔맥주", 3500);
		System.out.println(bok);
		
		

	}

}
