package com.keduitts;

public class SutdaCarTest {

	public static void main(String[] args) {
		
		SutdaCard card = new SutdaCard(3, false);
		SutdaCard cards = new SutdaCard();
		
		System.out.println(card.info());
		System.out.println(cards.info());

	}

}
