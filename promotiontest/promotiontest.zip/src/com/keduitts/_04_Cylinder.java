package com.keduitts;

public class _04_Cylinder{
	
	_03_Circle radius;
	double height;
	
	
	
	
	public _04_Cylinder(_03_Circle radius, double height) {
		this.radius = radius;
		this.height = height;
	}




	
//	public double getVolume() {
//		return _03_Circle.getArea()*height;
//	}
//	

}
