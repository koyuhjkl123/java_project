package com.keduitts;

public class _05_CylinderTest {

	public static void main(String[] args) {
		
		_04_Cylinder cd = new _04_Cylinder(new _03_Circle(2.8), 5.6);

	}

}
