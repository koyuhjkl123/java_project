package com.keduits;

public class _08_SutdaTest {

	public static void main(String[] args) {

		_06_SutdaDeck deck = new _06_SutdaDeck();
		for (int i = 0; i < deck.cards.length; i++)
			System.out.print(deck.cards[i] + ",");

	}

}
