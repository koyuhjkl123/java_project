package com.keduit;

public class Java_progams {

	public static void main(String[] args) {
		
		
		
	}

}
