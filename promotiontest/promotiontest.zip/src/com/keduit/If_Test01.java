package com.keduit;

public class If_Test01 {
	int sum = 0;
//	int i = 1;
	
	void DanMore() {
		
		
		
		
//		while(i < 100) {
//			if((i % 2 ==0) && (i % 7 ==0)){
//		sum += i;
//				
//			}
//			i++;
//			
//		}
//		System.out.println("100이하 자연수 중에서 2의 배수이자 7의 배수인 수 총 합: " + sum);
	}

	public static void main(String[] args) {
		
		If_Test01 ifs = new If_Test01();
		
		
		ifs.DanMore();
		
//		for(int i=0; i <=100; i++) {
//			sum += i;
//			
//		}
//		System.out.println("1 ~ 100까지의 합 : " + sum);
		
//		while(i < 100) {
//			i++;
//			System.out.println("1 ~ 100까지의 합 : " + i);
//		}
//		
//		do{
//			System.out.println("100 ~ 1까지 : " + i);
//			i--;
//		}while(i > 1);
//		System.out.println("100 ~ 0까지 : " + i);
		
		
		
		
	}

}
