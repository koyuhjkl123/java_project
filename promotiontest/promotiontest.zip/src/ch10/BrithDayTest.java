package ch10;

public class BrithDayTest {

	public static void main(String[] args) {
		
		BirthDay date = new BirthDay();
		date.setYear(2023);
		date.setMonth(12);
		date.setDay(30);
		
//		date.month = 100;
		date.showDate();

	}

}
