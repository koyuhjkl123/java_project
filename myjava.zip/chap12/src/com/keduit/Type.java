package com.keduit;

public enum Type {

	LAND, ISLAND
}
