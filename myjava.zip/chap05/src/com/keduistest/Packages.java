package com.keduistest;

import com.deduit._13_Circle;

public class Packages {

	public static void main(String[] args) {
		
		com.deduit._10_incrementTest gre = new com.deduit._10_incrementTest(); // 다른 패키지에서 가죠온 클래스
		// 코드가 지져분해지고 가독성이 떨어진다.
		
		_13_Circle c1 = new _13_Circle(10.0); // import문으로 사용할 경우
		
		
		
		

	}

}
