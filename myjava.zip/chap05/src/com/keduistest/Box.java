package com.keduistest;


class ColoredBox extends Box{

//	public ColoredBox(String s) {
//		super(s);
//	} 자식클래스에 super(s) 를 사용해야 사용이 가능하다
	// 부모 클래스가 매개변수가 있다면 디폴트 생성자가 만들지 않기 때문
	
}


public class Box {
	
//	public Box(String s) {} 
//	
	public Box() {}

	
	

	
	public static void main(String[] args) {
		
		
	}
}




