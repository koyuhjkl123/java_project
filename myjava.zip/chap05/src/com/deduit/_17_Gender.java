package com.deduit;

public enum _17_Gender {
	
	MALE, FEMALE

}
