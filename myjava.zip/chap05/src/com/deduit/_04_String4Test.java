package com.deduit;

public class _04_String4Test {

	public static void main(String[] args) {

		int i = 7;

		System.out.println("Java" + i);
		System.out.println("Java " + 7);
		System.out.println(7 + 1 + "Java " + 7 + 1);
		System.out.println(7 + 1 + "Java " + (7 + 1));

	}

}
