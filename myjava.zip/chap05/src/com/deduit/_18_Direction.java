package com.deduit;

public enum _18_Direction {

	EAST, WEST, SOUTH, NORTH
}
