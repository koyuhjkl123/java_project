package com.deduit;

public enum _23_Gender {

	여성, 남성
}
