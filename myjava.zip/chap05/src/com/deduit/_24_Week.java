package com.deduit;

public enum _24_Week {
	
	MONDAY, TUESDAY, WEDESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;
	

}
