package com.keduits;


public class Exam01_Circle {
	
	int radius;
	
	public Exam01_Circle(int radius) {
		this.radius = radius;
	}
	
	
	@Override // equals메소드의 오버라이드
	public boolean equals(Object obj) {
//		                  (형변환 할 클래스명)바꿀 클래스명
		Exam01_Circle ct =(Exam01_Circle)obj; // 다운캐스팅
//		Exam01_Circle의 참조하는 ct 변수를 obj 변수의 Object클래스가 
//		Exam01_Circle으로 타입 형변환을 하겠다 
		
		if(ct instanceof Object) {
			return this.radius == ct.radius;
//			현재 객체의 값인 radius와 비교대상 인 값 ct.radius 동일한지 비교
		}else {
			return false;
		}
	
		
	}
	

	
}
