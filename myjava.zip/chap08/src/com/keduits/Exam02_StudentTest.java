package com.keduits;

public class Exam02_StudentTest {

	public static void main(String[] args) {
		
		System.out.println(new Exam02_Student("김삿갓"));
		System.out.println(new Exam02_Student("홍길동"));

	}

}
