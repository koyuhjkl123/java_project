package com.keduits;

public class Exam04_DiceTest {

	public static void main(String[] args) {
		
		System.out.println(new Exam04_Dice().roll());

	}

}
