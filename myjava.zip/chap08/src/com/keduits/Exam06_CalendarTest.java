package com.keduits;

public class Exam06_CalendarTest {
	
	public static void main(String[] args) {
		
		Exam06_calendar c = new Exam06_calendar();
		
		
		c.show();
		
	}

}
