package com.keduit;

public class _05_MathTest {

	public static void main(String[] args) {

		System.out.println("Math.pow(2,9) : " + Math.pow(2, 9));
		System.out.println("Math.random(): " + (int)(Math.random() * 45 + 1));
		System.out.println("Math.sin(Math.PI): " + Math.sin(Math.PI));
		System.out.println("Math.min(10,20): " + Math.min(10, 20));

	}

}
