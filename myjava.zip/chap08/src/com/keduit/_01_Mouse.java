package com.keduit;

public class _01_Mouse {

	
	String name;
	
	public _01_Mouse(String name) {
		this.name = name;
	}
}
