package com.kediuts;

public class Exam06_MaxTest {

	public static void main(String[] args) {
		
		Exam06_Max<Number> n = new Exam06_Max<>();
		System.out.println(n.max(10, 8));
		System.out.println(n.max(8.1, 8));
		
		Exam06_Max<String> s = new Exam06_Max<>();
		System.out.println(s.max("Hello", "Hi"));
		System.out.println(s.max("Good", "moring"));

	}

}
