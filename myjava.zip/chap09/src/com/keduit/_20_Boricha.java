package com.keduit;

public class _20_Boricha extends _18_Beverage{
	
	@Override
	public String toString() {
		return "_20_Boricha...";
	}

}
