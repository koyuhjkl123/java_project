package com.keduit;

public class _02_Unchecked2Test {

	public static void main(String[] args) {
		
		int[] arr = {1, 2, 3};
		
		System.out.println(arr[3]);

	}

}
