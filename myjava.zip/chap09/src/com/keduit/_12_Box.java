package com.keduit;

public class _12_Box {

	private Object ob;
	
	
	
	public void setOb(Object ob) {
		this.ob = ob;
	}
	
	public Object getOb() {
		return ob;
	}
}
