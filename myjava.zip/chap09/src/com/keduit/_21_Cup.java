package com.keduit;

public class _21_Cup<T> {

	private T ob; // 제너릭 타입인 T

	public T get() {
		return ob;
	}

	public void set(T ob) {
		this.ob = ob;
	}

}
