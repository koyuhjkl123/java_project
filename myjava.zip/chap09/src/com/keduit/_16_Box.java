package com.keduit;

public class _16_Box<T> {

	private T ob;
	
	public void set(T ob) {
		this.ob = ob;
	}
	
	public T get() {
		return ob;
	}
}
