package com.keduit;

public class _19_Beer extends _18_Beverage{

	@Override
	public String toString() {
		return "Beer...";
	}
}
