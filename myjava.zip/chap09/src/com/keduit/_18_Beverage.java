package com.keduit;

public class _18_Beverage {
	
	public String toString() {
		return "_18_Beverage";
	}

}
