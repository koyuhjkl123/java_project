package com.keduit;

public class _11_Orange {

	
	public String toString() {
		return "I am Orange.";
	}
}
