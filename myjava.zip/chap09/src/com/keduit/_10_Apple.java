package com.keduit;

public class _10_Apple {
	

	
	@Override
	public String toString() {
		return "I am apple.";
	}
}
