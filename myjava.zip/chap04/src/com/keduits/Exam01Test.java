package com.keduits;

public class Exam01Test {

	public static void main(String[] args) {
		
		Exam01 r = new Exam01(10.0, 5.0);
		
		System.out.println(r.findArea());

	}

}
