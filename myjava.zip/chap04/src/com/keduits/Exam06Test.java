package com.keduits;

public class Exam06Test {

	public static void main(String[] args) {
		
		Exam06 E1 = new Exam06(2.0); // e2는 0.0 자동초기화
		
		E1.print();
		Exam06 E2 = new Exam06(1.5, 2.5);
		E2.print();

	}

}
