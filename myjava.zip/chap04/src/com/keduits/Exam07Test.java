package com.keduits;

public class Exam07Test {
	
	public static void main(String[] args) {
		
		
		
		Exam07 g1 = new Exam07();
		g1.prints();
		
		Exam07 g2 = new Exam07(8);
		g2.prints();
		
		Exam07 g3 = new Exam07("퍼터");
		g3.prints();
		
		
		
		
	}

	
	
}
