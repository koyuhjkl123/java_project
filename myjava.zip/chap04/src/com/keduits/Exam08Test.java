package com.keduits;

public class Exam08Test {

	public static void main(String[] args) {
		
		
		Exam08 d = new Exam08();
		System.out.println("주사위의 숫자 : " + d.roll());
	}

}
