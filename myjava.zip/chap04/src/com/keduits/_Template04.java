package com.keduits;

public class _Template04 {

	public static void main(String[] args) {
		
		for(int i = 0; i < 5; i++) {
			for(int y = 0; i >= y; y++) {
				System.out.print("*");
			}
			System.out.println("");
		}
		
		

	}

}
