package com.keduit;

public class _06_Cirlcle {
	
	private double radius;
	
	public _06_Cirlcle() {}
	public _06_Cirlcle(double dadius) {
		this.radius = radius;
	}

}
