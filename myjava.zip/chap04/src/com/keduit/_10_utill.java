package com.keduit;

public class _10_utill {
	
	static int fourTimes(int i) {
		return i *4;
	}

}
