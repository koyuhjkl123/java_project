package com.keduit;

public class _09_Circle {
	
	double radius;
	
	static int numOfCicle = 0;
	int numCircle = 0;
	
	
	public _09_Circle(double radius) {
		this.radius = radius;
		
		numOfCicle++;
		numCircle++;
	}
	
	

}
