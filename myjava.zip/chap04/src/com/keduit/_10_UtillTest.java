package com.keduit;

public class _10_UtillTest {

	public static void main(String[] args) {
		
		System.out.println(_10_utill.fourTimes(5));

	}

}
