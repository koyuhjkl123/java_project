package com.keduit;

public class _01Phone {
	String model;
	int value;

	void print() {
		System.out.println(value + "만원짜리 " + model + "스마트폰");
	}

}
