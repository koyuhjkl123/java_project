package com.keduit;

public class _06_CircleTest {

	public static void main(String[] args) {
		
		_06_Cirlcle myCirlcle = new _06_Cirlcle();
		_06_Cirlcle myCirlcle1 = new _06_Cirlcle(10.0);
		
		System.out.println(myCirlcle);
		System.out.println(myCirlcle1);
		
		

	}

}
