package com.keduit;

public class _08_PersonTest {

	public static void main(String[] args) {

		_08_Person person = new _08_Person();
		
//		person.setName("홍길동");
//		person.setName("홍길동").setAge(25);
//		person.print();
//		person.setName("홍길동").setAge(25).print();
//		person.setName("홍길동").print().setAge(25); print() void 이기 때문에 맨 뒤에 있어야 한다.
		
	}

}
