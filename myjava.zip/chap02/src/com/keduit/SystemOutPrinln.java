package com.keduit;

import java.util.Scanner;

public class SystemOutPrinln {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println(7);
		System.out.println(3.14);
		System.out.println("3 + 5 = " + 3+5);
		System.out.println(3.14 + "는 실수입니다. ");
		System.out.println("3 + 5" + "의 연산 결과는 8입니다.");
		System.out.println(3+5);
				

	}

}
