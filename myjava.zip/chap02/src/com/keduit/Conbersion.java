package com.keduit;

public class Conbersion {

	public static void main(String[] args) {
		
		double d = 3.14f;
		
		System.out.println(d);
		
		float f = 3.14f;
		System.out.println(f);
		
		byte x = (byte)3.14;
		System.out.println(x);
		
		byte b = (byte)257;
		System.out.println(b);
		
		System.out.println(Byte.MAX_VALUE);
		System.out.println(Byte.MIN_VALUE);
	}

}
