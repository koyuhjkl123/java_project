package com.keduit;

public class Boolean {

	public static void main(String[] args) {
		
		boolean b1 = true;
		boolean b2 = false;
		
		System.out.println(b1);
		System.out.println(b2);
		
		int num1 = 10;
		int num2 = 20;
		
		System.out.println(num1 > num2);
		System.out.println(num2 > num1);

	}

}
