package com.keduit;

public class VarTest {

	String b;
	int m;
	String s;

	public static void main(String[] args) {

		var a = 1;
		int var = 1;

		var ch01 = '#';
		var str01 = "Hello";

	}

	void test() {

	}

	public VarTest(int m, String b) {

	}

}
