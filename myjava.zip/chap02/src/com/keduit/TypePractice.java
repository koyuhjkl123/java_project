package com.keduit;

public class TypePractice {

	public static void main(String[] args) {
		
		System.out.println("Byte의 최소값 : " + Byte.MIN_VALUE);
		System.out.println("Byte의 최대값 : " + Byte.MAX_VALUE);
		
		System.out.println("Short의 최소값 : " + Short.MIN_VALUE);
		System.out.println("Short의 최대값 : " + Short.MAX_VALUE);
		
		System.out.println("Integer의 최소값 : " + Integer.MIN_VALUE);
		System.out.println("Integer의 최대값 : " + Integer.MAX_VALUE);
		
		System.out.println("Float의 최소값 : " + Float.MIN_VALUE);
		System.out.println("Float의 최대값 : " + Float.MAX_VALUE);
		
		System.out.println("Long의 최소값 : " + Long.MIN_VALUE);
		System.out.println("Long의 최대값 : " + Long.MAX_VALUE);
		
		

	}

}
