package com.keduit;

public class Constent {

	public static void main(String[] args) {
		
		final int MAX_SIZE = 100;
		final char CONST_CHAR = '상';
		
		final int CONST_ASSIGNED;
		
		CONST_ASSIGNED = 12;
		
		System.out.println("상수1 : " + MAX_SIZE);
		System.out.println("상수2 : " + CONST_ASSIGNED);
		System.out.println("상수3 : " + CONST_CHAR);

	}

}
