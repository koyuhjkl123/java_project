package com.keduit;

public class Singnniment {

	public static void main(String[] args) {
		
		int plusOne = 1;
		int minusOne = -plusOne;
		System.out.println("plusOne은 " + plusOne + "입니다.");
		System.out.printf("minusOne은 %d 입니다.\n" , minusOne);

		
		int x = 1, y = 1;
		System.out.printf("x = %d, ++x = %d\n", x, ++x);
		System.out.printf("y = %d, y++ = %d\n", y, y++);
		System.out.printf("x = %d, y = %d\n", x, y);
		
		
		
		
		
		
		
		
	}

}
