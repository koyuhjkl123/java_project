package text;

public class Exam_09 {

	public static void main(String[] args) {
		
		
		int sum = 0;
		int i = 1;
		int s = 0;
		
		while(i <= 100) {
			System.out.println(i);
			i++;
		}
		
		do {
			i--;
			System.out.println(i);
		} while (i > 1);
		
	}

}
