package text;

public class Exam_02 {

	public static void main(String[] args) {
		
		
		double a = 10.0;
		double height = 10.0;
		double sum = (double)(a * a *3.14* height);
		
		System.out.printf("원기둥의 밑면 반지름 : %.1f\n", a);
		System.out.printf("원기둥의 높이는 : %.1f\n", height);
		System.out.printf("원기둥의 부피는 : %.1f\n", sum);
		

	}

}
