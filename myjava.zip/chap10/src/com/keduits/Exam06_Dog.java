package com.keduits;

public class Exam06_Dog extends Exam06_Animal{

	@Override
	public void sound() {
		System.out.println("멍멍");
	}
}
