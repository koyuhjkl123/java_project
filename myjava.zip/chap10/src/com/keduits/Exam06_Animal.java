package com.keduits;

public class Exam06_Animal {
	
	public void sound() {
		System.out.println("ㅁㅁㄲㄲ ...");
	}

}
