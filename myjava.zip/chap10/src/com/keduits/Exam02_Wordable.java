package com.keduits;

public interface Exam02_Wordable {
	
	void word(); // 추상메서드

}
