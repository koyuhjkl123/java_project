package com.keduit;

public interface _13_Mathemtical {
	
	double calculate(double a);

}
