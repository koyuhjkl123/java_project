package com.keduit;

public class _12_Utils {

	int add(int a, int b) {
		return a + b;
	}
}
