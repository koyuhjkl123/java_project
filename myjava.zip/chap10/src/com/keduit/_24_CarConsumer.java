package com.keduit;


@FunctionalInterface
public interface _24_CarConsumer {

	
	void accept(_22_Car car);
}
