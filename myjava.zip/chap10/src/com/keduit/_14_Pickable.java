package com.keduit;

public interface _14_Pickable {

	char pick(String s, int i);
}
