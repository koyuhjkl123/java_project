package com.keduit;

public interface CalulteTest {

	int max(int a, int b);

}

