package com.keduit;

@FunctionalInterface
public interface _08_Calulate<T> {
	
	T cal(T a, T b);

}
