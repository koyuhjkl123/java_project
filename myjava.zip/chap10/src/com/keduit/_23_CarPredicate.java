package com.keduit;

@FunctionalInterface
public interface _23_CarPredicate {
	
	
	boolean test(_22_Car car);

}
