package com.keduit;

public interface CalulteTest5 {
	int roll();
}
