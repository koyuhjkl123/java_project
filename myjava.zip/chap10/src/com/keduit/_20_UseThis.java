package com.keduit;

public interface _20_UseThis {
	void use();

}
