package com.keduit;

public class _09_CalulateTest {

	public static void main(String[] args) {
		
		_08_Calulate<Integer> ci = (x, y) -> x + y;
		
		System.out.println(ci.cal(5, 7));

	}

}
