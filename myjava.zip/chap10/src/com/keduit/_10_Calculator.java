package com.keduit;

public class _10_Calculator {

	public static int staticMethod(int x, int y) {
		return x + y;
	}

	public int instanceMethod(int x, int y) {
		return x + y;
	}
}
