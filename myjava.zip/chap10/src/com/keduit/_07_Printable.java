package com.keduit;

public interface _07_Printable {

	void print();
}
