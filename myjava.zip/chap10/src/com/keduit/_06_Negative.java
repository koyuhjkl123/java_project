package com.keduit;

public interface _06_Negative {
	
	int neg(int x);

}
