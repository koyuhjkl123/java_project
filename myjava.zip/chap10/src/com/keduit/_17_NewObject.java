package com.keduit;

@FunctionalInterface
public interface _17_NewObject<T> {
	
	T getObject(T o);

}
