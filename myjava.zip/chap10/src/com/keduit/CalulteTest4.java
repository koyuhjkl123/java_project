package com.keduit;

public interface CalulteTest4 {
	int square(int x);
}
