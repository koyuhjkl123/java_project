package com.keduit;

public interface _15_Computable {

	int compute(int x, int y);
}
