package com.keduit;

public interface CalulteTest3 {
	void printVar(String name, int i);
}
