package com.keduit;

public interface _18_NewArray<T> {
	
	T[] getArray(int size);

}
