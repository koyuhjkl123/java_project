package com.keduit;

public class _13_CoinTest {

	public static void main(String[] args) {

		// interface 필드는 객체 생성 없이 사용 가능
		System.out.println("Dime은 " + _12_Coin.DIME + " 센트입니다.");
//		_12_Coin.NICKEL = 5; // final 상수이기 때문에 값 변경 x
		
		
	}

}
