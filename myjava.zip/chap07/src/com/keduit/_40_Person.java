package com.keduit;

public class _40_Person {

	void wake() {
		System.out.println("7시에 일어납니다.");
	}

}
