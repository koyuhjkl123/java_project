package com.keduit;

public interface _20_Portable {
	
	void inMyBag();

}
