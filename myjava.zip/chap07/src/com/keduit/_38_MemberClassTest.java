package com.keduit;

public class _38_MemberClassTest {
	
	public static void main(String[] args) {
		
		_37_MeberTest me = new _37_MeberTest();
		
		me.e.move();
		me.e.sound();
	}

}
