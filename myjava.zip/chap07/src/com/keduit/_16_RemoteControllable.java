package com.keduit;

public interface _16_RemoteControllable extends _15_Controllable{

	// 추상메소드, 선언만 되어 있음
	void remoteOn();
	void remoteOff();
	
	
	
	
}
