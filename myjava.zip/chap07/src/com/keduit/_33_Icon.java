package com.keduit;

public class _33_Icon {
	
	interface Touchable{
		void touch(); // 추상메소드
	}

}
