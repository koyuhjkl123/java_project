package com.keduit;

public class _49_CalcTest {

	public static void main(String[] args) {
		
		_48_Anonymous a = new _48_Anonymous();
		a.method(10, 20);

	}

}
