package com.keduit;

public interface _47_Calculatable {

	int sum();
}
