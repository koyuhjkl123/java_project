package com.keduit;

public class _46_WindowTest {

	public static void main(String[] args) {
		
		_45_window w = new _45_window();
		
		w.button1.touch(); 
//		button1.setOnClickListener(listener); 변수가 있는 객체
		w.button2.touch();
//		button2.setOnClickListener(
//		 new _44_OnClickListener() { // 익명 객체
		

	}

}
