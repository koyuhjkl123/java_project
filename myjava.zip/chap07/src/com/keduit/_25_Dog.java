package com.keduit;

public class _25_Dog implements _24_Animal{

	@Override // 추상 메소드 자식클래스에서 구현
	public void sound() {
		System.out.println("멍멍~~~~~");
	}
	
	

	
}
