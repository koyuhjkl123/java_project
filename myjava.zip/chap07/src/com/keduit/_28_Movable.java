package com.keduit;

public interface _28_Movable {
	
	void move(int s); // 추상메소드

}
