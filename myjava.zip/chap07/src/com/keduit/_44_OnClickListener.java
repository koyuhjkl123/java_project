package com.keduit;

public interface _44_OnClickListener {

	
	void onClick(); // 추상 메소드
}
