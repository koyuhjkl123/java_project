package com.keduit;

public interface _12_Coin {
	// 인터페이스 필드
	
	int PENNY = 1;
	int NICKEL = 5;
	int DIME = 10;
	int QUARTER = 25;

}
