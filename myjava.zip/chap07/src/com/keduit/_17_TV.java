package com.keduit;

public class _17_TV implements _15_Controllable{

	@Override
	public void turnOn() {
		System.out.println("TV를  켭니다.");
		
	}

	@Override
	public void turnOff() {
		System.out.println("TV를 끕니다.");
	}

	
}
