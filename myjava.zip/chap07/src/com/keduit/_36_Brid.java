package com.keduit;

public class _36_Brid {
	
	void move() {
		System.out.println("새가 날아요");
	}

}
