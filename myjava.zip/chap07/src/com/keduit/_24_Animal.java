package com.keduit;

public interface _24_Animal {

	void sound(); // 추상 메소드
}
