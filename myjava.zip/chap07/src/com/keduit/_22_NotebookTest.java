package com.keduit;

public class _22_NotebookTest {

	public static void main(String[] args) {

		_21_Notebook note = new _21_Notebook();
		
		note.turnOn();
		note.repair();
		note.turnOff();
		note.inMyBag();
	}

}
