package com.keduits;

public class Exam04_Korean implements Exam04_Talkable{

	@Override
	public void talk() {
		System.out.println("안녕하세요!");
	}
	
	

}
