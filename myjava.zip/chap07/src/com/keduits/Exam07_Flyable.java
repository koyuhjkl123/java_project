package com.keduits;

public interface Exam07_Flyable {
	
	void speed(); // 추상메서드
	void height(); // 추상 메서드

}
