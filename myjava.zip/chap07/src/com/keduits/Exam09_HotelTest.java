package com.keduits;

public class Exam09_HotelTest {

	public static void main(String[] args) {
		
		Exam09_Hotel hotel = new Exam09_Hotel();
		
		hotel.add(5, "호돌이");
		hotel.add(7, "길동이");
		hotel.show();
		
		
		

	}

}
