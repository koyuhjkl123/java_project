package com.keduits;

public interface Exam04_Talkable {
	
	void talk(); // 추상 메서드

}
