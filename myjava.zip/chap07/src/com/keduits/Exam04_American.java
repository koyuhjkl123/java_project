package com.keduits;

public class Exam04_American implements Exam04_Talkable{

	@Override
	public void talk() {
		System.out.println("Hello!");
	}
	
}
