package com.keduits;

public class Exam01_ConcreteTest {

	public static void main(String[] args) {
		
		Exam01_Concrete c = new Exam01_Concrete(100, 50);
		
		c.show();

	}

}
