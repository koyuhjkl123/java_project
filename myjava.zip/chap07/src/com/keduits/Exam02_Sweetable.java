package com.keduits;

public interface Exam02_Sweetable {
	
	void sweet(); // 추상 메소드

}
