package com.keduits;

public class Exam09_Hotel2Test {

	public static void main(String[] args) {
		
		Exam09_Hotel2 hotel = new Exam09_Hotel2();
		
		hotel.add(5, "호돌이");
		hotel.add(5, "길동이");
		hotel.add(7, "백동이");
		hotel.show();

	}

}
