package com.keduits;

public interface Exam02_Edible {
	
	void eat(); // 추상 메소드

}
