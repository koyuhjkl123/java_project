package com.keduits;

public class Exam06_worker  implements Exam06_Human{

	@Override
	public void eat() {
		System.out.println("빵을 먹습니다.");
	}
	
	
	

}
