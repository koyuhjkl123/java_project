package com.keduits;

public abstract class Exam05_Controller { // 추상클래스
	
	boolean power;
	
	void show() { // 인스턴스메서드
	}
	
	abstract String getName(); // 추상메서드

}
