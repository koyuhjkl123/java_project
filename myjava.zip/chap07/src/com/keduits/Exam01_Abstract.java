package com.keduits;

public abstract class Exam01_Abstract { // 추상 클래스
	
	int i; // int 타입 필드
	
	
	abstract void show(); // 추상 메서드 선언부

}
