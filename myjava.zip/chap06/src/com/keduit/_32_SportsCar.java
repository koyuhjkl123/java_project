package com.keduit;

public class _32_SportsCar extends _30_Car{
	
	
	@Override
	// 실제 객체 : 객체를 참조를 바라보는 인스턴스 메서드
	void whoami() { // 오버라이딩 된 "실제 객체" 메서드
		System.out.println("나는 스포츠 자동차입니다.");
		
	}

}
