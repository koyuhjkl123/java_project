package com.keduit;

//public class _19_NumberOne extends _18_Best{
	public class _19_NumberOne{

}
