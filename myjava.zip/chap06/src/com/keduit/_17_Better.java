package com.keduit;

public class _17_Better extends _16_Good{

//	Chessplayer getFirstPlayer() {}
}
