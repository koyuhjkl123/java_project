package com.keduit.other;

import com.keduit._11_One;

public class _15_Three {

	void print() {
		_11_One o = new _11_One();
		
//		System.out.println(o.secret);
//		System.out.println(o.roommate);
//		System.out.println(o.child);
		System.out.println(o.anybody);

	}
}
