package com.keduit;

public class _29_Vehicle {

	
	String name = "탈 것";
	
	void whoami() {
		System.out.println("탈것입니다.");
	}
	
	static void move() {
		System.out.println("이동합니다.");
	}
	
	
}
