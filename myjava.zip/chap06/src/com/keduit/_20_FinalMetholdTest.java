package com.keduit;

public class _20_FinalMetholdTest {

	public static void main(String[] args) {
		
		_17_Better w = new _17_Better();
		
		System.out.println(w.getFirstPlayer()); 

	}

}
