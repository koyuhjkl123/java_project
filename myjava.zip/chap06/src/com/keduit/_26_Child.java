package com.keduit;

public class _26_Child extends _25_Parent {

	
	@Override
	public void methold2() {
		System.out.println("child-methold2");
	}
	public void methold3() {
		System.out.println("child-methold3");
	}
	
}
