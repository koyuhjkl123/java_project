package com.keduit;

public class _22_Student extends _21_Person{

	
	int number = 7;
	
	void work() {
		System.out.println("나는 공부합니다.");
	}
	
	
}
