package com.keduit;

public class _04_Airpane {
	
	
	public void Isnd() {
		System.out.println("착류합니다.");
	}
	
	protected void fly() {

		System.out.println("일반 비행");
	}
	
	public void takeOff() {
		System.out.println("이륙합니다.");
	}

}
