package com.keduit;

public class _16_Good {

	enum Chessplayer{
		WHITE, BLACK
		
	}
	
	final Chessplayer getFirstPlayer() {
		return Chessplayer.WHITE;
	}
}
