package com.keduit;


public class _10_AnimalTest {

	public static void main(String[] args) {
		
		_09_Mammal ape = new _09_Mammal(); // 디폴트 생성자 호출
		_09_Mammal lion = new _09_Mammal("사자"); // 매개변수 존재하는 디폴트 생성자

	}

}
