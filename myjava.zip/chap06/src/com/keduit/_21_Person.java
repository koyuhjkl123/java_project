package com.keduit;

public class _21_Person {
	
	String name = "사람";
	
	void whoami() {
		System.out.println("나는 사람입니다.");
	}

}
