package com.keduit;

public class _08_Animal {

	public _08_Animal(String s) {
		System.out.println("동물 : " + s); // 생성자가 있으므로 디폴트 생성자x
	}
}
