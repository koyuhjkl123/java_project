package com.keduit;

public class _27_ChildTest {

	public static void main(String[] args) {
		
		_26_Child child = new _26_Child();
		_25_Parent parent =  child;
		
		parent.methold1();
		parent.methold2();
//		parent.methold3();

	}

}
