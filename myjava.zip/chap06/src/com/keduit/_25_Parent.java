package com.keduit;

public class _25_Parent {
	
	public void methold1() {
		System.out.println("Parent-methold1()");
	}
	
	public void methold2() {
		System.out.println("Parent-methold2()");
	}

}
