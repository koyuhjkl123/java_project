package com.keduit.pro;

public class Exam03_PointTest {

	public static void main(String[] args) {
		
		Exam03_MovalblePoint mo = new Exam03_MovalblePoint(3, 5, 100, 150);
		
		System.out.println(mo.toString());

	}

}
