package com.keduit.pro;

public class Exam01Test {

	public static void main(String[] args) {
		
		Exam01 e = new Exam01(5);
		Exam01 ex = new Exam01_ColorCircle(10, "빨간색");
		
		
		e.show();
		ex.show();

	}

}
