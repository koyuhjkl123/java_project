package com.keduit.pro;

public class Exam04_Parent {
	
	String name = "영조";
	
	void print() {
		System.out.println(name);
	}
	

}
