package com.keduit.pro;

public class Exam04_Child extends Exam04_Parent{
	
	String name = "사도세자";
	
	void print() {
		System.out.println("나는 " + name + "이다.");
	}

}
