package com.keduit.pro;

public class Exam01 {
	
	int radius; 
	
	void show() {
		System.out.printf("반지름이 %d인 원이다.\n",radius);
	}
	
	public Exam01(int radius) {
		this.radius = radius;
	}
	
	

}
