package com.keduit;

final public class _18_Best extends _17_Better{

}
