package com.keduit;

public class _11_One {

	private int secret = 1;
	int roommate =2; // 디폴트 접근 제어자
	protected int child = 3;
	public int anybody = 4;
	
	public _11_One(){
		
	}
	
	public void show() {
		
	}
	

}
