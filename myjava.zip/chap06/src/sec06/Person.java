package sec06;

public class Person {

	String name = "사람";
	
	void whoami() {
		System.out.println("나는 사람이다.");
	}
}
