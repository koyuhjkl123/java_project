package sec06;

public class Student extends Person{
	
	int number = 7;
	
	void work() {
		System.out.println("나는 공부한다.");
	}

}
