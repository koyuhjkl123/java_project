package sec06;

public class BestGirl extends GoodGirl { //

	public BestGirl(String name) {
		super(name);
	}

	void show() {
		System.out.println(name+"그녀는 자바를 무지하게 잘 안다");
	}

}
