package sec06.other;

public class Test2 extends One{

	
	
	
}
