package sec06;

public class Girl { // 최상위 클래스

	public String name;
	
	void show() {
		System.out.println(name+"는 자바 초보자이다.");
	}
	public Girl(String name) {
		this.name = name;
	}
	
}
