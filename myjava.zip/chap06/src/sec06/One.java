package sec06;

public class One {

	private int secret = 1;
	int roommate =2; // 디폴트 접근 제어자
	protected int child = 3;
	public int anybody = 4;
	
	public One(){
		
	}
	
	public void show() {
		
	}
	

}
