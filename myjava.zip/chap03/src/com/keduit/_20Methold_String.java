package com.keduit;

public class _20Methold_String {

	public static void echo(String x, int i) {

		for (int y = 0; y < i; y++) {
			System.out.println(x);
		}
	}
	
	

	public static void main(String[] args) {

		echo("안녕!", 2);

	}

}
