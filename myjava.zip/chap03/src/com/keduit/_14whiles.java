package com.keduit;

public class _14whiles {

	public static void main(String[] args) {
		
		
		
		

	}

}
