package com.keduit;

public class _06While2 {

	public static void main(String[] args) {

		
//		
		int s= 2;
		
		while(s < 10) {
			int i = 1;
			while(i < 10) {
				System.out.printf("%4d",s*i);
				i++;
			}
			System.out.println();
			s++;
			
		}
		
		

	}

}
