package databace;

import java.io.BufferedReader;

import java.io.InputStreamReader;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Ailrport extends Ailrports{
	
	
	Connection con;
	public Ailrport() throws Exception {

		String driver = "com.mysql.cj.jdbc.Driver";
		String sql_url = "jdbc:mysql://localhost:3306/sakila";
		String userid = "root";
		String pwd = "548312";

			Class.forName(driver);
			con = DriverManager.getConnection(sql_url, userid, pwd);
			System.out.println("연결 성공 하였습니다.");

	}

	public void database() {
		
		String result = "";

		try {
			URL url = new URL(
					"https://apis.data.go.kr/1160100/service/GetStockSecuritiesInfoService/getStockPriceInfo?serviceKey=B0n71QWQYKWw2A85EXRc5IQbV1P29e6lKpPlaefJZR4ls84%252BKV8HhzYR7pC6oK0wh0CUhKHZMR4z79CrhJhGUQ%253D%253D&numOfRows=10000&pageNo=10&resultType=json");
			    // 응답 형식을 JSON으로 설정
			BufferedReader bf = new BufferedReader(new InputStreamReader(url.openStream(), "UTF-8"));
			result = bf.readLine();

			
			JSONParser parser = new JSONParser();
			JSONObject jsonObj = (JSONObject) parser.parse(result); // json가져온거 파싱함 반환값이 object니까 jsonobject타입으로 형변환해서
																	// jsonobj에 넣어줌
		
			JSONObject response = (JSONObject) jsonObj.get("response"); // jsonobj에서 response 꺼내서 그것도 object타입이니까
																		// jsonobject타입으로 형변환
			JSONObject body = (JSONObject) response.get("body"); // get을 어디서해오느냐 주의!!
			JSONObject items = (JSONObject) body.get("items");
			JSONArray item = (JSONArray) items.get("item"); // 이건 배열이였으니까.
			
			System.out.println("종목명	날짜	종가	전일대비	등락률	시가	  고가    저가");

		String sql_create = "create table ailrport ("
				+ "num int auto_increment not null primary key,"
				+ "itmsNm VARCHAR(40) not null,"
				+ "basDt VARCHAR(40) not null,"
				+ "clpr VARCHAR(40) not null,"
				+ "vs VARCHAR(40) not null,"
				+ "fltRt VARCHAR(40) not null,"
				+ "mkp VARCHAR(40) not null,"
				+ "hipr VARCHAR(40) not null,"
				+ "lopr VARCHAR(40) not null)";
		
		try {
			Statement stmt = con.createStatement();
			stmt.execute(sql_create);
		} catch (Exception e) {
			e.printStackTrace();
		}
			
			for(int i = 0; i < item.size(); i++) {
				JSONObject itmsNm = (JSONObject) item.get(i);
				String itmsNms = (String) itmsNm.get("itmsNm"); // 종목명
				String mrktTotAmt = (String) itmsNm.get("mrktTotAmt"); // 시가총액
				String mrktCtg = (String) itmsNm.get("mrktCtg"); // 시장 구분
				String clpr = (String) itmsNm.get("clpr"); // 종가
				String basDt = (String) itmsNm.get("basDt"); // 기준일자
				String vs = (String) itmsNm.get("vs"); // 대비
				String fltRt = (String) itmsNm.get("fltRt"); // 등락률
				String trqu = (String) itmsNm.get("trqu"); // 거래량
				String mkp = (String) itmsNm.get("mkp"); // 시가
				String hipr = (String) itmsNm.get("hipr"); // 고가
				String lopr = (String) itmsNm.get("lopr"); // 저가
				
				setItmsNms(itmsNms);
				setBasDt(basDt);
				setClpr(clpr);
				setVs(vs);
				setFltRt(fltRt);
				setMkp(mkp);
				setHipr(hipr);
				setLopr(lopr);
				System.out.print(itmsNms +"  "+basDt + "  " + clpr + "  " + vs + "  " + fltRt +
						"  " + mkp + "  " + hipr + "  " +  lopr + "\n"); // 날짜, 종가
				
				String  sql_insert = "insert into ailrport(itmsNm, basDt, clpr, vs, fltRt, mkp, hipr, lopr) values (?, ?, ?, ?, ?, ?, ?, ?)";
				
				PreparedStatement pstmt = con.prepareStatement(sql_insert);
				pstmt = con.prepareStatement(sql_insert);
				pstmt.setString(1, getItmsNms());
				pstmt.setString(2, getBasDt());
				pstmt.setString(3, getClpr());
				pstmt.setString(4, getVs());
				pstmt.setString(5, getFltRt());
				pstmt.setString(6, getMkp());
				pstmt.setString(7, getHipr());
				pstmt.setString(8, getLopr());
				
				int result_sum = pstmt.executeUpdate();
				 if (result_sum == 1) {
					 System.out.println("정보 업데이트 완료되었습니다.");
				 }else {
					 System.out.println("정보 업데이트 실패되었습니다.");
				 }
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public static void main(String[] args) throws Exception {

		Ailrport a = new Ailrport();
		
		a.database();
		
	

}}