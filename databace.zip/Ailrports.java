package databace;

public class Ailrports {
	
	private String itmsNms; // 종목명
	private String mrktCth; // 시가 총액
	private String basDt; // 기준 일자
	private String fltRt; // 등락률
	private String trqu; // 거래량
	private String vs; // 대비
	private String clpr; // 종가
	private String mkp; // 시가
	private String hipr; // 고가
	private String lopr; // 저가
	
	
	public String getVs() {
		return vs;
	}
	public void setVs(String vs) {
		this.vs = vs;
	}
	public String getClpr() {
		return clpr;
	}
	public void setClpr(String clpr) {
		this.clpr = clpr;
	}
	public String getMkp() {
		return mkp;
	}
	public void setMkp(String mkp) {
		this.mkp = mkp;
	}
	public String getHipr() {
		return hipr;
	}
	public void setHipr(String hipr) {
		this.hipr = hipr;
	}
	public String getLopr() {
		return lopr;
	}
	public void setLopr(String lopr) {
		this.lopr = lopr;
	}
	public String getFltRt() {
		return fltRt;
	}
	public String getTrqu() {
		return trqu;
	}
	public String getEndFltRt() {
		return fltRt;
	}
	public void setFltRt(String fltRt) {
		this.fltRt = fltRt;
	}
	public String getEndTrqu() {
		return trqu;
	}
	public void setTrqu(String trqu) {
		this.trqu = trqu;
	}
	public String getItmsNms() {
		return itmsNms;
	}
	public void setItmsNms(String itmsNms) {
		this.itmsNms = itmsNms;
	}
	public String getMrktCth() {
		return mrktCth;
	}
	public void setMrktCth(String mrktCth) {
		this.mrktCth = mrktCth;
	}
	public String getBasDt() {
		return basDt;
	}
	public void setBasDt(String basDt) {
		this.basDt = basDt;
	}
	
	

}
